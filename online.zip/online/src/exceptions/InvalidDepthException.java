package src.exceptions;

// Definizione delle eccezioni controllate
public class InvalidDepthException extends Exception {
    public InvalidDepthException(String message) {
        super(message);
    }
}


