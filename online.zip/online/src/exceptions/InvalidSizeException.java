package src.exceptions;

public class InvalidSizeException extends Exception {
    public InvalidSizeException(String message) {
        super(message);
    }
}